/* ============================================================
   SOLVENS AMORIS — particles.js
   Sistema de partículas místicas + campo estelar
   ============================================================ */

(function () {
  'use strict';

  /* ── CONFIG ── */
  const CFG = {
    STARS:      120,   // puntos de fondo
    PARTICLES:  35,    // partículas flotantes
    SYMBOLS: ['✦', '✧', '⋆', '·', '⁎', '✴', '⁂'],
  };

  /* ── Campo estelar estático ── */
  function createStars() {
    const container = document.getElementById('stars');
    if (!container) return;

    const frag = document.createDocumentFragment();
    for (let i = 0; i < CFG.STARS; i++) {
      const el = document.createElement('div');
      el.className = 'star-dot';

      const size = Math.random() * 2.5 + 0.5;
      const x    = Math.random() * 100;
      const y    = Math.random() * 100;
      const dur  = (Math.random() * 4 + 2).toFixed(1);
      const del  = (Math.random() * 5).toFixed(1);

      el.style.cssText = `
        width:${size}px;
        height:${size}px;
        left:${x}vw;
        top:${y}vh;
        animation-duration:${dur}s;
        animation-delay:${del}s;
      `;
      frag.appendChild(el);
    }
    container.appendChild(frag);
  }

  /* ── Partículas flotantes ── */
  function createParticles() {
    const container = document.getElementById('particles');
    if (!container) return;

    const colors = ['#d4af37', '#ffe48c', '#8b6fff', '#c8a8ff', '#ffffff'];

    for (let i = 0; i < CFG.PARTICLES; i++) {
      spawnParticle(container, colors, i * 400);
    }
  }

  function spawnParticle(container, colors, initialDelay) {
    const el = document.createElement('div');
    el.className = 'particle';

    const isSymbol = Math.random() > 0.55;
    const size     = isSymbol
      ? (Math.random() * 10 + 8)
      : (Math.random() * 3 + 1);

    const x    = Math.random() * 100;
    const dur  = (Math.random() * 18 + 10).toFixed(1);
    const del  = (Math.random() * 8 + initialDelay / 1000).toFixed(2);
    const col  = colors[Math.floor(Math.random() * colors.length)];

    if (isSymbol) {
      el.textContent = CFG.SYMBOLS[Math.floor(Math.random() * CFG.SYMBOLS.length)];
      el.style.cssText = `
        font-size:${size}px;
        left:${x}vw;
        bottom:-5vh;
        color:${col};
        opacity:0;
        animation-duration:${dur}s;
        animation-delay:${del}s;
      `;
    } else {
      el.style.cssText = `
        width:${size}px;
        height:${size}px;
        left:${x}vw;
        bottom:-5vh;
        background:${col};
        opacity:0;
        animation-duration:${dur}s;
        animation-delay:${del}s;
      `;
    }

    container.appendChild(el);

    /* Reiniciar al terminar para efecto continuo */
    const totalMs = (parseFloat(dur) + parseFloat(del)) * 1000;
    setTimeout(() => {
      el.remove();
      spawnParticle(container, colors, 0);
    }, totalMs + 500);
  }

  /* ── Init cuando el DOM está listo ── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  function init() {
    createStars();
    createParticles();
  }

})();
