/* ============================================================
   SOLVENS AMORIS — script.js
   Efectos interactivos: fase lunar, parallax, hover mágico
   ============================================================ */

(function () {
  'use strict';

  /* ── 1. FASE LUNAR REAL ──────────────────────────────── */
  function getMoonPhase() {
    const CYCLE   = 29.53058867;
    const KNOWN   = new Date('2000-01-06T18:14:00Z'); // luna nueva conocida
    const now     = new Date();
    const diff    = (now - KNOWN) / 86400000; // días
    const phase   = ((diff % CYCLE) + CYCLE) % CYCLE;
    return phase;
  }

  function getMoonEmoji(phase) {
    // 0 = luna nueva, 14.76 = luna llena
    if (phase < 1.85)  return { emoji: '🌑', name: 'Luna Nueva' };
    if (phase < 5.55)  return { emoji: '🌒', name: 'Cuarto Creciente' };
    if (phase < 9.25)  return { emoji: '🌓', name: 'Cuarto Creciente' };
    if (phase < 12.95) return { emoji: '🌔', name: 'Gibosa Creciente' };
    if (phase < 16.65) return { emoji: '🌕', name: 'Luna Llena' };
    if (phase < 20.35) return { emoji: '🌖', name: 'Gibosa Menguante' };
    if (phase < 24.05) return { emoji: '🌗', name: 'Cuarto Menguante' };
    if (phase < 27.75) return { emoji: '🌘', name: 'Cuarto Menguante' };
    return { emoji: '🌑', name: 'Luna Nueva' };
  }

  function updateMoonSection() {
    const moonEl = document.getElementById('moon');
    if (!moonEl) return;

    const phase = getMoonPhase();
    const { emoji, name } = getMoonEmoji(phase);
    const allMoons = ['🌑', '🌒', '🌓', '🌔', '🌕', '🌖', '🌗', '🌘'];

    // Resaltar la fase actual
    const spans = allMoons.map((m) => {
      const isCurrent = m === emoji;
      return `<span class="${isCurrent ? 'moon-active' : ''}" title="${isCurrent ? name : ''}">${m}</span>`;
    });

    moonEl.innerHTML = spans.join(' ');
    moonEl.setAttribute('title', `Fase actual: ${name}`);
  }

  /* ── 2. PARALLAX SUAVE EN ZODIACO ─────────────────── */
  function initParallax() {
    const zodiac   = document.getElementById('zodiac');
    const magicAura = document.getElementById('magicAura');
    if (!zodiac) return;

    let ticking = false;

    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          const scrollY = window.scrollY;
          const offsetZ = scrollY * 0.15;
          const offsetA = scrollY * 0.08;

          if (zodiac)    zodiac.style.transform    = `translateX(-50%) translateY(${offsetZ}px)`;
          if (magicAura) magicAura.style.transform = `translateX(-50%) translateY(${offsetA}px)`;

          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });
  }

  /* ── 3. CURSOR / MOUSE AURA ─────────────────────── */
  function initMouseAura() {
    const aura = document.getElementById('magicAura');
    if (!aura || window.matchMedia('(pointer: coarse)').matches) return;

    // Solo en desktop con mouse
    document.addEventListener('mousemove', (e) => {
      const cx = window.innerWidth  / 2;
      const cy = window.innerHeight / 2;
      const dx = (e.clientX - cx) * 0.03;
      const dy = (e.clientY - cy) * 0.03;

      aura.style.transform = `translateX(calc(-50% + ${dx}px)) translateY(${dy}px)`;
    }, { passive: true });
  }

  /* ── 4. RIPPLE EN CARDS ──────────────────────────── */
  function initCardRipple() {
    document.querySelectorAll('.card').forEach((card) => {
      card.addEventListener('click', function (e) {
        const rect   = this.getBoundingClientRect();
        const ripple = document.createElement('span');
        const size   = Math.max(rect.width, rect.height);
        const x      = e.clientX - rect.left - size / 2;
        const y      = e.clientY - rect.top  - size / 2;

        ripple.style.cssText = `
          position:absolute;
          width:${size}px;
          height:${size}px;
          left:${x}px;
          top:${y}px;
          background:radial-gradient(circle, rgba(212,175,55,0.4), transparent 70%);
          border-radius:50%;
          transform:scale(0);
          animation:rippleAnim 0.6s ease-out forwards;
          pointer-events:none;
          z-index:0;
        `;

        this.style.position = 'relative';
        this.style.overflow = 'hidden';
        this.appendChild(ripple);

        setTimeout(() => ripple.remove(), 700);
      });
    });

    // Inyectar keyframe si no existe
    if (!document.getElementById('rippleStyle')) {
      const st = document.createElement('style');
      st.id = 'rippleStyle';
      st.textContent = `@keyframes rippleAnim {
        to { transform: scale(2.5); opacity: 0; }
      }`;
      document.head.appendChild(st);
    }
  }

  /* ── 5. LUNA ACTIVA: estilo ────────────────────── */
  function injectMoonStyle() {
    if (document.getElementById('moonActiveStyle')) return;
    const st = document.createElement('style');
    st.id = 'moonActiveStyle';
    st.textContent = `
      .moon-active {
        font-size: 1.6em;
        filter: drop-shadow(0 0 8px gold) drop-shadow(0 0 16px #ffe48c);
        animation: moonPulse 2s ease-in-out infinite !important;
        animation-delay: 0s !important;
        display: inline-block;
      }
      @keyframes moonPulse {
        0%, 100% { transform: scale(1)    translateY(0); }
        50%       { transform: scale(1.3)  translateY(-8px); }
      }
    `;
    document.head.appendChild(st);
  }

  /* ── 6. FRASE CÍCLICA EN #QUOTE ─────────────────── */
  const FRASES = [
    '"Lo que buscas, también te busca."',
    '"El universo conspira a favor de quienes se atreven."',
    '"En cada carta está escrito tu nombre."',
    '"Amor fati — ama tu destino."',
    '"Las estrellas no mienten; los hombres las mal interpretan."',
  ];

  function initQuoteCycle() {
    const quoteEl = document.getElementById('quote');
    if (!quoteEl) return;

    let idx = 0;

    setInterval(() => {
      idx = (idx + 1) % FRASES.length;
      quoteEl.style.opacity = '0';
      quoteEl.style.transform = 'translateY(10px)';

      setTimeout(() => {
        quoteEl.textContent = FRASES[idx];
        quoteEl.style.transition = 'opacity 0.8s, transform 0.8s';
        quoteEl.style.opacity = '1';
        quoteEl.style.transform = 'translateY(0)';
      }, 500);
    }, 6000);
  }

  /* ── INIT ──────────────────────────────────────── */
  function init() {
    injectMoonStyle();
    updateMoonSection();
    initParallax();
    initMouseAura();
    initCardRipple();
    initQuoteCycle();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
